import {initializeApp} from 'firebase/app'

const app = initializeApp({

    apiKey: "AIzaSyCx1a7PuG6K-JaSW8OiE9g1rx3j9ORsYKA",
    authDomain: "react-quiz-dev-7dd6b.firebaseapp.com",
    projectId: "react-quiz-dev-7dd6b",
    storageBucket: "react-quiz-dev-7dd6b.appspot.com",
    messagingSenderId: "857103210547",
    appId: "1:857103210547:web:f13d58bed61d574eba2b46",
    databaseURL: "https://react-quiz-dev-7dd6b-default-rtdb.europe-west1.firebasedatabase.app"

})

export default app;