import React from 'react'
import Illustration from '../Illustration'
import classes from '../../styles/Signup.module.css'
import LoginForm from '../LoginForm'

export default function Signup() {
  return (
    <>
    <h1>Create an account</h1>
    
    <div className={classes.column}>

        <Illustration/>
        <LoginForm/>
    </div>
    </>
  )
}
