import React from 'react'
import { Link } from 'react-router-dom'
import classes from '../../styles/startpage.module.css'

export default function StartPage() {
  return (
    <div className={classes.container}>
      <div className={classes.containerData}>

        <div className={classes.text1}>
          <span className={classes.quizz_name}>Quiz Game</span>
        </div>

        <div className={`${classes.startButton} ${classes.text3}`}>
          <Link className={classes.buttonStart} to={'/login'}>Let's play</Link>
          <h5 className={classes.beTheFirstH5}>...and be the first</h5>
        </div>

      </div>
    </div>
  )
}
